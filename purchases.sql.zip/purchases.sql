-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Апр 20 2022 г., 11:13
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kasper012_kapita`
--

-- --------------------------------------------------------

--
-- Структура таблицы `purchases`
--
-- Создание: Апр 20 2022 г., 07:58
-- Последнее обновление: Апр 20 2022 г., 08:07
--

DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `session_id` text NOT NULL,
  `order_desc` text NOT NULL,
  `card_number` char(16) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `order_status` text NOT NULL,
  `response_description` text NOT NULL,
  `amount` float(11,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `purchases`
--

INSERT INTO `purchases` (`id`, `order_id`, `session_id`, `order_desc`, `card_number`, `date`, `order_status`, `response_description`, `amount`) VALUES
(51, 43026610, 'DEB2AB9B74532BC45013BFF26E6CBAB7', 'Some description', '416974XXXXXX8741', '2022-04-20 08:04:19', 'DECLINED', 'Maximum number of times used', 10.00),
(52, 43026610, 'DEB2AB9B74532BC45013BFF26E6CBAB7', 'Some description', '416974XXXXXX8741', '2022-04-20 08:04:19', 'DECLINED', 'Maximum number of times used', 10.00),
(53, 43026610, 'DEB2AB9B74532BC45013BFF26E6CBAB7', 'Some description', '416974XXXXXX8741', '2022-04-20 08:04:19', 'DECLINED', 'Maximum number of times used', 10.00),
(54, 43026610, 'DEB2AB9B74532BC45013BFF26E6CBAB7', 'Some description', '416974XXXXXX8741', '2022-04-20 08:04:19', 'DECLINED', 'Maximum number of times used', 10.00),
(55, 43026610, 'DEB2AB9B74532BC45013BFF26E6CBAB7', 'Some description', '416974XXXXXX8741', '2022-04-20 08:04:19', 'DECLINED', 'Maximum number of times used', 10.00),
(56, 43026748, 'B8DADD3CA096D247E65C0F1514E01AAE', 'Lorem ipsum', '416974XXXXXX8741', '2022-04-20 08:06:29', 'DECLINED', 'Maximum number of times used', 10.33),
(57, 43026792, 'CC1BB7989FD979FC8E75A761F3A5D0E8', 'Lorem ipsum dolor sit amet', '416974XXXXXX8741', '2022-04-20 08:07:04', 'DECLINED', 'Maximum number of times used', 15.00);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `purchases`
--
ALTER TABLE `purchases`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
